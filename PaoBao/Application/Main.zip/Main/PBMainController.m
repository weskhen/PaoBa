//
//  PBMainController.m
//  PaoBao
//
//  Created by wujian on 2017/3/14.
//  Copyright © 2017年 wujian. All rights reserved.
//

#import "PBMainController.h"
#import "PBMainControllerProtocol.h"
#import "PBMainInteractor.h"
#import "PBMainPresenter.h"
#import "PBMainView.h"

@interface PBMainController ()<PBMainControllerProtocol>

@property (nonatomic, strong) PBMainPresenter *mainPresenter;
@property (nonatomic, strong) PBMainInteractor *mainInteractor;

@end

@implementation PBMainController
@synthesize presenter = _presenter;
@synthesize interactor = _interactor;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _presenter = self.mainPresenter;
    _interactor = self.mainInteractor;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - PBMainControllerProtocol
- (void)setControllerFromSource:(PBMainControllFrom)source
{
    
}

#pragma mark - setter/getter
- (PBMainPresenter *)mainPresenter
{
    if (_mainPresenter == nil) {
        _mainPresenter = [PBMainPresenter new];
        _mainPresenter.baseController = self;
    }
    return _mainPresenter;
}

- (PBMainInteractor *)mainInteractor
{
    if (_mainInteractor == nil) {
        _mainInteractor = [PBMainInteractor new];
        _mainInteractor.baseController = self;
    }
    return _mainInteractor;
}
@end
