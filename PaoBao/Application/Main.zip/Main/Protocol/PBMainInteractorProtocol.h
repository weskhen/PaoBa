//
//  PBMainInteractorProtocol.h
//  PaoBao
//
//  Created by wujian on 2017/3/14.
//  Copyright © 2017年 wujian. All rights reserved.
//

#ifndef PBMainInteractorProtocol_h
#define PBMainInteractorProtocol_h

@protocol PBMainInteractorProtocol <NSObject>

//PBMainInteractor 界面交互
- (void)gotoSecondController;

@end

#endif /* PBMainInteractorProtocol_h */
