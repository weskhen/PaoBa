//
//  PBMainPresenterProtocol.h
//  PaoBao
//
//  Created by wujian on 2017/3/14.
//  Copyright © 2017年 wujian. All rights reserved.
//

#ifndef PBMainPresenterProtocol_h
#define PBMainPresenterProtocol_h


@protocol PBMainPresenterProtocol <NSObject>

//PBMainPresenter 业务逻辑
- (NSArray *)getMainTableDataArray;


@end
#endif /* PBMainPresenterProtocol_h */
